package Automation.steps;

import static org.testng.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class LoginSteps {
	
	WebDriver driver;
	
	@Before()
	public void setup() {
		System.setProperty("webdriver.chrome.driver", "D:\\workspace\\selenium\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.addArguments("headless");
		this.driver = new ChromeDriver(chromeOptions);
		this.driver.manage().window().maximize();
		this.driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
	}
	
	@After()
	public void test(Scenario scenario) throws Throwable{
		if(scenario.isFailed()) {
			scenario.embed(((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES), "image/png");
		}
		this.driver.close();
		this.driver.quit();
	}
	
	// Basic scenario
	@Given("^User navigate to stack overflow website$")
	public void user_navigate_to_NBS_website() throws Throwable {
	   driver.get("https://stackoverflow.com/");
	}
	
	@Given("^User navigate to \"([^\"]*)\" NBS website$")
	public void user_navigate_to_url_NBS_website() throws Throwable {
	   driver.get("https://stackoverflow.com/");
	}

	@Given("^User click on Log in$")
	public void user_click_on_login() throws Throwable {
		driver.findElement(By.xpath("//a[contains(text(), 'Log in')]")).click();
	}
	
	@Given("^User enter valid user name$")
	public void user_enter_valid_user_name() throws Throwable {
		driver.findElement(By.xpath(".//*[@id='email']")).sendKeys("shsuneel@gmail.com");
	}
	
	@Given("^User enter invalid user name$")
	public void user_enter_invalid_user_name() throws Throwable {
		driver.findElement(By.xpath(".//*[@id='email']")).sendKeys("invalid@gmail.com");
	}

	@Given("^User enter \"([^\"]*)\" password$")
	public void user_enter_password(String ss, DataTable dt) throws Throwable {
		List<List<String>> data = dt.raw();
		driver.findElement(By.xpath(".//*[@id='password']")).sendKeys(data.get(0).get(0));
	}
	
	@When("^User click on login button$")
	public void user_click_on_login_button() throws Throwable {
		driver.findElement(By.xpath(".//*[@id='submit-button']")).click();
	}

	@Then("^User should be taken to the successfull login page$")
	public void user_should_be_taken_to_the_successfull_login_page() throws Throwable {
		Thread.sleep(2000);
		WebElement  askQuestionBtn = driver.findElement(By.xpath("//a[contains(text(), 'Ask Question')]"));
		Assert.assertEquals(true, askQuestionBtn.isDisplayed());
	}
	
	@Then("^User should see invalid username and password error message$")
	public void User_should_see_invalid_username_and_password_error_message() throws Throwable {
		Thread.sleep(2000);
		WebElement  errorMessage = driver.findElement(By.xpath("//p[contains(text(), 'The email or password is incorrect')]"));
		Assert.assertNotNull(errorMessage);
	}
	
	// Outline scenario
	
	@Given("^I navigate to Registration form page$")
	public void i_navigate_to_NBS_website() throws Throwable {
		String url = "http://127.0.0.1:8081/components/registration-form/";
	   driver.get(url);
	}
	
	@Given("^I enter username as \"([^\"]*)\"$")
	public void i_enter_username(String userName) throws Throwable {
		driver.findElement(By.xpath(".//*[@id='userName']")).sendKeys(userName);
	}
	
	@Given("^I enter firstname as \"([^\"]*)\"$")
	public void i_enter_firstname(String firstname) throws Throwable {
		driver.findElement(By.xpath(".//*[@id='fName']")).sendKeys(firstname);
	}
	
	@Given("^I enter lastname as \"([^\"]*)\"$")
	public void i_enter_lastname(String lastName) throws Throwable {
		driver.findElement(By.xpath(".//*[@id='lName']")).sendKeys(lastName);
	}
	
	@Given("^I enter email as \"([^\"]*)\"$")
	public void i_enter_email(String email) throws Throwable {
		driver.findElement(By.xpath(".//*[@id='email']")).sendKeys(email);
	}
	
	@Given("^I enter password as \"([^\"]*)\"$")
	public void i_enter_password(String password) throws Throwable {
		driver.findElement(By.xpath(".//*[@id='password']")).sendKeys(password);
	}
	
	@Given("^I enter confirm password as \"([^\"]*)\"$")
	public void i_enter_confirm_password(String password) throws Throwable {
		driver.findElement(By.xpath(".//*[@id='confirmPassword']")).sendKeys(password);
	}
	
	@When("^I click on register button$")
	public void i_click_on_login_button() throws Throwable {
		driver.findElement(By.xpath(".//*[@id='signUpForm']/button")).click();
		
	}

	@Then("^I should see the \"([^\"]*)\" as per details entered$")
	public void i_should_be_taken_to_the_successfull_login_page(String message) throws Throwable {
		if(message.contains("invalid")) {
			System.out.println(message);
			String[] arrOfStr = message.split("-", 5);
			WebElement  inputField = driver.findElement(By.xpath(".//*[@id='"+ arrOfStr[1] +"']"));
			String validationMessage = inputField.getAttribute("validationMessage");
			assertEquals(validationMessage, arrOfStr[2]);
		}
		else {
			Alert alert = driver.switchTo().alert();
			assertEquals(alert.getText(), message);
			alert.accept();
		}
	}
			
}
