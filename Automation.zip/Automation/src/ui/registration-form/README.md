# Registration Form

to run this

- npm install -g bower polyserve

- bower install

- polyserve